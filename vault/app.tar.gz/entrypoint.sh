apt update && apt install nodejs npm -y

cd /app

npm install

npm run serve
